const express = require('express')
const router = express.Router()
const fs = require('fs')
const path = require('path')
const { pool } = require('../db/db')

// Example: get users (no tool details exposed)
router.get('/users', async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT id, username, role FROM users')
    res.json(rows)
  } catch (err) {
    res.status(500).json({ error: 'Failed to get users' })
  }
})

// Example: audit logs (no tool details exposed)
router.get('/audit', async (req, res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 100')
    res.json(rows)
  } catch (err) {
    res.status(500).json({ error: 'Failed to get audit logs' })
  }
})

// Admin-only: view tool audit log
router.get('/tool-audit', (req, res) => {
  if (req.user.role !== 'admin') return res.sendStatus(403)
  const logFilePath = path.resolve(__dirname, '../../secure_logs/tool_audit.log')
  if (!fs.existsSync(logFilePath)) return res.status(404).send('No tool audit log')
  const logs = fs.readFileSync(logFilePath, 'utf8')
  res.type('text/plain').send(logs)
})

module.exports = router