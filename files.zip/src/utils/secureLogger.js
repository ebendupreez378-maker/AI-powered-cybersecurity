const winston = require('winston')
const fs = require('fs')
const path = require('path')

// Secure log file for tool interactions (outside webroot, only for admins)
const logFilePath = path.resolve(__dirname, '../../secure_logs/tool_audit.log')
fs.mkdirSync(path.dirname(logFilePath), { recursive: true })

const secureTransport = new winston.transports.File({
  filename: logFilePath,
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  )
})

// Standard transport for regular logs
const normalTransport = new winston.transports.Console()

// Logger for general application
const logger = winston.createLogger({
  level: 'info',
  transports: [normalTransport]
})

// Logger for tool interactions (admin only, not exposed to users)
const toolLogger = winston.createLogger({
  level: 'info',
  transports: [secureTransport]
})

function logToolInteraction({ userId, toolName, action, status }) {
  // Only minimal info, no payloads or API keys
  toolLogger.info({
    userId,
    toolName,
    action,
    status,
    timestamp: new Date().toISOString()
  })
}

module.exports = { logger, logToolInteraction }