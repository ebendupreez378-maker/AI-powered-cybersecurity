require('dotenv').config()
const express = require('express')
const http = require('http')
const cors = require('cors')
const helmet = require('helmet')
const morgan = require('morgan')
const { Server } = require('socket.io')
const adminRoutes = require('./routes/admin')
const { authenticateJWT } = require('./middleware/auth')
const logger = require('./utils/logger')
const { pool, redisClient } = require('./db/db')

const app = express()
const server = http.createServer(app)
const io = new Server(server, { cors: { origin: '*' } })

// Middlewares
app.use(cors())
app.use(helmet())
app.use(express.json())
app.use(morgan('combined', { stream: logger.stream }))

// API routes
app.use('/api/admin', authenticateJWT, adminRoutes)

// Simple health check
app.get('/api/health', (req, res) => res.json({ status: 'ok' }))

// Realtime threat stream (demo)
io.on('connection', (socket) => {
  logger.info(`Socket connected: ${socket.id}`)
  socket.on('subscribeThreats', () => {
    // Example: emit a threat every 5s
    const interval = setInterval(() => {
      socket.emit('threat', { timestamp: Date.now(), level: 'info', message: 'No threats detected.' })
    }, 5000)
    socket.on('disconnect', () => clearInterval(interval))
  })
})

const PORT = process.env.PORT || 4000
server.listen(PORT, () => logger.info(`Server running on port ${PORT}`))