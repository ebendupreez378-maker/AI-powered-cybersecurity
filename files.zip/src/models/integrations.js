const { logToolInteraction } = require('../utils/secureLogger')
const { Configuration, OpenAIApi } = require("openai")
const { VertexAI } = require("@google-cloud/aiplatform")
const SuperengineerAI = require("superengineerai-sdk")

// Only log tool interaction, never expose details to non-admin
async function callOpenAI(prompt, userId) {
  let status = 'fail'
  try {
    const openai = new OpenAIApi(new Configuration({ apiKey: process.env.OPENAI_API_KEY }))
    await openai.createChatCompletion({
      model: "gpt-4",
      messages: [{ role: "system", content: prompt }]
    })
    status = 'success'
  } catch (e) {
    status = 'fail'
  }
  logToolInteraction({ userId, toolName: "OpenAI", action: "call", status })
  return status === 'success' ? { status: "ok" } : { status: "error" }
}

async function callVertexAI(text, userId) {
  let status = 'fail'
  try {
    const vertex = new VertexAI({ projectId: process.env.GCP_PROJECT_ID })
    const endpoint = vertex.endpoint(process.env.VERTEX_ENDPOINT)
    await endpoint.predict({ instances: [{ content: text }] })
    status = 'success'
  } catch (e) {
    status = 'fail'
  }
  logToolInteraction({ userId, toolName: "VertexAI", action: "call", status })
  return status === 'success' ? { status: "ok" } : { status: "error" }
}

async function callSuperengineerAIScan(url, userId) {
  let status = 'fail'
  try {
    const client = new SuperengineerAI.Client({ apiKey: process.env.SUPERENGINEER_API_KEY })
    await client.scanUrl(url)
    status = 'success'
  } catch (e) {
    status = 'fail'
  }
  logToolInteraction({ userId, toolName: "SuperengineerAI", action: "scan", status })
  return status === 'success' ? { status: "ok" } : { status: "error" }
}

module.exports = { callOpenAI, callVertexAI, callSuperengineerAIScan }