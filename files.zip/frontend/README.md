# Frontend Stub

This backend is ready for a React.js or Next.js frontend.

## Features to Build

- Admin login (JWT)
- Dashboard: Threats, users, audit logs (live via Socket.IO)
- User/role management
- Config panel (API keys, thresholds)
- Connect to backend: REST API `/api/*`, Socket.IO for `threat` events

## Quick Start

1. Create a new React app (`npx create-react-app frontend`)
2. Install `socket.io-client` and your UI library
3. Connect to `ws://localhost:4000` for real-time threats
4. Fetch `/api/admin/*` endpoints for admin features